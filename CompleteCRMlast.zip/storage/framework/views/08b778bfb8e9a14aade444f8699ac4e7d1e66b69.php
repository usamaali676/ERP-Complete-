<?php $__env->startSection('content'); ?>
<?php if(Auth::check()): ?>
<?php
// $mperm = App\Models\perm;
$user = Auth::user();
$perm = App\Models\perm::where('role_id', $user->role_id)->where('name', "desig")->first();
// $permuser = App\Models\perm::where('role_id', $user->role_id)->where('name', "Users")->first();
// $permsheet = App\Models\perm::where('role_id', $user->role_id)->where('name', "Sales")->first();
?>
<?php endif; ?>
        <!-- BEGIN: Content -->
        <div class="content content--top-nav">
            <div class="intro-y flex items-center mt-8">
                <h2 class="text-lg font-medium mr-auto">
                    Roles
                </h2>
               <?php if($perm->create == 1): ?>
               <a href="<?php echo e(route('desig.create')); ?>" class="btn btn-primary shadow-md mr-2">Add New Designation</a>
               <?php endif; ?>
            </div>
                                <!-- BEGIN: Striped Rows -->
                                <div class="intro-y box mt-5">
                                    <div class="p-5" id="striped-rows-table">
                                        <div class="preview">
                                            <div class="overflow-x-auto">
                                                <table id="example" class="table table-report">
                                                    <thead>
                                                        <tr>
                                                            <th class="whitespace-nowrap">Sr.</th>
                                                            <th class="whitespace-nowrap">Name</th>
                                                            <th class="whitespace-nowrap">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $desig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($srno++); ?></td>
                                                            <td><?php echo e($item->name); ?></td>
                                                             <td> <?php if($perm->edit == 1 ): ?><a class="btn btn-warning mr-1 mb-2" href="<?php echo e(route('desig.edit',$item->id)); ?>" > <i data-lucide="edit" style="color: #fff" class="w-5 h-5"></i> </a><?php endif; ?> <?php if($perm->view == 1): ?><a href="<?php echo e(route('desig.detail', $item->id)); ?>" class="btn btn-success mr-1 mb-2"> <i data-lucide="eye" class="w-5 h-5" style="color: #fff"></i> </a><?php endif; ?> <?php if($perm->delete == 1  ): ?><a  href="<?php echo e(route('desig.conf-delete', $item->id)); ?>"  class="btn btn-danger mr-1 mb-2"> <i data-lucide="trash" class="w-5 h-5"></i> </a><?php endif; ?> </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- END: Striped Rows -->
        </div>
        <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\CompleteCRM\resources\views/designation/index.blade.php ENDPATH**/ ?>