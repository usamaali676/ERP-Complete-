<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content content--top-nav">
        <div class="intro-y flex items-center mt-8">
            <h2 class="text-lg font-medium mr-auto">
                Fine Edit
            </h2>
        </div>
        <!-- BEGIN: Input -->
        <div class="intro-y box mt-4">

            <div id="input" class="p-5">
                <div class="preview">
                    <form action="<?php echo e(route('fine.update', $fine->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <div class="mt-3">
                            <div class="grid grid-cols-12 gap-6 mt-5">
                                <div class="col-span-12 lg:col-span-6">
                                    <label for="tomselect-1">Select User </label>
                                    <div class="mt-2">
                                        <select name="user_id"  data-placeholder="Select User" class="tom-select w-full " >
                                            <?php if($selectuser != null): ?>
                                            <option value="<?php echo e($selectuser->id); ?>"><?php echo e($selectuser->name); ?></option>
                                            <?php else: ?>
                                            <option value="">Please Select</option>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="intro-y col-span-12 lg:col-span-6">
                                    <label for="regular-form-3" class="form-label">Amount</label>
                                    <input id="regular-form-3" name="amount" type="text" class="form-control" placeholder="Amount" value="<?php echo e($fine->amount); ?>">
                                </div>
                            </div>
                            <div class="grid grid-cols-12 gap-6 mt-5">
                                <div class="intro-y col-span-12 lg:col-span-6">
                                    <label for="regular-form-3" class="form-label">Date</label>
                                    <input id="regular-form-3" name="date" type="date" class="form-control" placeholder="Date" value="<?php echo e($fine->date); ?>">
                                </div>
                                <div class="intro-y col-span-12 lg:col-span-6">
                                    <label for="regular-form-3" class="form-label">Reason</label>
                                    <input id="regular-form-3" name="reason" type="text" class="form-control" placeholder="Reason" value="<?php echo e($fine->reason); ?>">
                                </div>


                        <button type="submit" class="btn btn-primary mt-5">Submit</button>
                    </form>
                </div>
            </div>
            <!-- END: Input -->
        </div>
        <!-- END: Content -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\CompleteCRM\resources\views/fine/edit.blade.php ENDPATH**/ ?>