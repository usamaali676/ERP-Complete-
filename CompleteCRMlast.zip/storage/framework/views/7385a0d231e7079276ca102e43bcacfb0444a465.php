<?php $__env->startSection('content'); ?>
<?php if(Auth::check()): ?>
<?php
// $mperm = App\Models\perm;
$user = Auth::user();
// $perm = App\Models\perm::where('role_id', $user->role_id)->where('name', "Roles")->first();
// $permuser = App\Models\perm::where('role_id', $users->role_id)->where('name', "Users")->first();
// $permsheet = App\Models\perm::where('role_id', $user->role_id)->where('name', "Sales")->first();
$permcmnt = App\Models\perm::where('role_id', $user->role_id)->where('name', "cmnt")->first();
?>
<?php endif; ?>
    <!-- BEGIN: Content -->

    <div class="intro-y flex items-center mt-8">
        <h2 class="text-lg font-medium mr-auto">
            Edit Client
        </h2>
    </div>
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 lg:col-span-12">
            <!-- BEGIN: Form Layout -->
            <form action="<?php echo e(route('cmnt.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <div class="intro-y box p-5">
                    <div class="grid grid-cols-12 gap-6 mt-5">
                        <div class="intro-y col-span-12 lg:col-span-12">
                            <label for="crud-form-1" class="form-label">Client Business Name</label>
                            <input id="crud-form-1" type="text" class="form-control w-full"
                                placeholder="Client Business Name" value="<?php echo e($sale->business_name); ?>" readonly>
                                <input id="crud-form-1" type="hidden" class="form-control w-full"
                                placeholder="Client Business Name" name="sales_id" value="<?php echo e($sale->id); ?>" >
                        </div>
                    </div>
                    <div class="grid grid-cols-12 gap-6 mt-5">
                        <div class="intro-y col-span-12 lg:col-span-12">
                            <label>Additional Links</label>
                            <div class="mt-3">
                                <textarea name="text" class="editor" id="editor"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="text-right mt-5">
                        <a href="<?php echo e(url()->previous()); ?>"  class="btn btn-outline-secondary w-24 mr-1">Cancel</a>
                        <button type="submit" class="btn btn-primary w-24">Save</button>
                    </div>
                </div>
            </form>
            <!-- END: Form Layout -->
        </div>
    </div>
    <?php if($permcmnt->view == 1): ?>
    <div class="intro-y box mt-5">
        <div class="p-5" >
                <div class="overflow-x-auto">

                    <table id="example" class="table table-report">
                                        <thead>
                                            <tr>
                                                <th class="whitespace-nowrap">Sr.</th>
                                                <th class="whitespace-nowrap">Comment</th>
                                                <th class="whitespace-nowrap">Date</th>

                                                <?php if($permcmnt->edit == 1 || $permcmnt->delete == 1): ?> <th class="whitespace-nowrap">Action</th><?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $sale->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($srno++); ?></td>
                                                <td><?php echo $item->text; ?></td>
                                                <td><?php echo e($item->date); ?></td>

                                                <td><?php if($permcmnt->edit == 1): ?><a class="btn btn-warning mr-1 mb-2" href="<?php echo e(route('cmnt.edit',$item->id)); ?>" > <i data-lucide="edit" style="color: #fff" class="w-5 h-5"></i> </a><?php endif; ?> <?php if($permcmnt->delete == 1): ?><a href="<?php echo e(route('cmnt.delete', $item->id)); ?>" onclick="return confirm('Are you sure you want to delete this item')" class="btn btn-danger mr-1 mb-2"> <i data-lucide="trash" class="w-5 h-5"></i> </a><?php endif; ?> </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                </table>
            </div>

        </div>
    </div>
    <?php endif; ?>
    <!-- END: Content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/ckeditor-classic.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\CompleteCRM\resources\views/sale/add_comment.blade.php ENDPATH**/ ?>