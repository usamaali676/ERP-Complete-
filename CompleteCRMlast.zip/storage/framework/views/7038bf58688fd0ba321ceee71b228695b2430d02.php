<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content content--top-nav">
        <div class="intro-y flex items-center mt-8">
            <h2 class="text-lg font-medium mr-auto">
                Edit Holiday Cycle
            </h2>
        </div>
        <!-- BEGIN: Input -->
        <div class="intro-y box mt-4">

            <div id="input" class="p-5">
                <div class="preview">
                    
                    <form action="<?php echo e(route('holiday.update',$holiday->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <div class="mt-3">
                            <div class="grid grid-cols-12 gap-6 mt-5">
                                <div class="col-span-12 lg:col-span-6">
                                    <div class="mt-2">
                                        <label for="regular-form-3" class="form-label">Name</label>
                                        
                                            <select id="user_select"data-placeholder="Select User" class="tom-select w-full" name="user_id">
                                                <?php if(isset($selecteduser)): ?>
                                                    <option value="<?php echo e($selecteduser->id); ?>"><?php echo e($selecteduser->name); ?></option>
                                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option>Please Select</option>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        
                                    </div>
                                </div>
                                <div class="col-span-12 lg:col-span-6">
                                    <div class="mt-2">
                                        <label for="regular-form-3" class="form-label">Year</label>
                                        <input id="regular-form-3" name="year" type="text"  class="form-control" placeholder="Holiday Year" value="<?php echo e($holiday->year); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-3">
                            <div class="grid grid-cols-12 gap-6 mt-5">
                                <div class="intro-y col-span-12 lg:col-span-6">
                                    <label for="regular-form-3" class="form-label">Total</label>
                                    <input id="regular-form-3" name="total" type="text" value="<?php echo e($holiday->total); ?>" class="form-control" placeholder="Total Holidays" >
                                </div>
                                <div class="intro-y col-span-12 lg:col-span-6">
                                    <label for="vehicle-type" class="form-label">Remaining</label>
                                    <input id="regular-form-3" name="remaining" type="number" value="<?php echo e($holiday->remaining); ?>" max="<?php echo e($holiday->total); ?>" class="form-control" placeholder="Remaining Holidays" >

                                </div>
                            </div>
                        </div>



                        <button type="submit" class="btn btn-primary mt-5">Submit</button>
                    </form>
                </div>
            </div>
            <!-- END: Input -->
        </div>
        <!-- END: Content -->
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function(){
      $('input.month-count').change(function(){
        jan = $("input[name='jan']").val();
        feb = $("input[name='feb']").val();
        mar = $("input[name='mar']").val();
        apr = $("input[name='apr']").val();
        may = $("input[name='may']").val();
        jun = $("input[name='jun']").val();
        jul = $("input[name='jul']").val();
        aug = $("input[name='aug']").val();
        sep = $("input[name='sep']").val();
        oct = $("input[name='oct']").val();
        nov = $("input[name='nov']").val();
        dec = $("input[name='dec']").val();
        // var sum = jan + feb + mar + apr + may + jun + jul + aug + sep + oct + nov + dec ;
        var sum = parseInt(jan) + parseInt(feb) + parseInt(mar) + parseInt(apr) +
           parseInt(may) + parseInt(jun) + parseInt(jul) + parseInt(aug) +
           parseInt(sep) + parseInt(oct) + parseInt(nov) + parseInt(dec);
        total =  $("input[name='total']").val();
        if(sum > total)
        {
            alert("You Don't Have Enough Remainnigs Holidays!");
        }
        // alert(sum);
      });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\CompleteCRM\resources\views/holiday/edit.blade.php ENDPATH**/ ?>