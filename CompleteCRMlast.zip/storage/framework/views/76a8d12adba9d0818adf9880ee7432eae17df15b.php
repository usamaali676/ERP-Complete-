<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content content--top-nav">
        <div class="intro-y flex items-center mt-8">
            <h2 class="text-lg font-medium mr-auto">
                Create User
            </h2>
        </div>
        <!-- BEGIN: Input -->
        <div class="intro-y box mt-4">

            <div id="input" class="p-5">
                <div class="preview">
                    <form action="<?php echo e(route('user.update',$user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <div class="grid grid-cols-12 gap-6 mt-5">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-3">
                                    <label for="regular-form-3" class="form-label">Name</label>
                                    <input id="regular-form-3" name="name" type="text" class="form-control"
                                        placeholder="User Name" value="<?php echo e($user->name); ?>">
                                </div>
                            </div>
                            <?php if($user->role_id == 1): ?>
                            <input type="hidden" name="role_id" value="<?php echo e($user->role_id); ?>">
                            <?php else: ?>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-3">
                                    <label>Role</label>
                                    <div class="mt-2">
                                        <select class="tom-select w-full" name=role_id >
                                            <?php if($selectedRole!=null): ?>
                                            <option value="<?php echo e($selectedRole->id); ?>"><?php echo e($selectedRole->name); ?></option>
                                            <?php else: ?>
                                            <option value="">Please Select</option>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($list->id != 1): ?>
                                                <option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label>Designation</label>
                                    <div class="mt-2">
                                        <select data-placeholder="Select Designation" class="tom-select w-full" name="desig_id">
                                            <?php if($selectedDesig != null): ?>
                                            <option value="<?php echo e($selectedDesig->id); ?>" selected><?php echo e($selectedDesig->name); ?></option>
                                            <?php else: ?>
                                            <option >Please Select</option>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $designation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label>Department</label>
                                    <div class="mt-2">
                                        <select data-placeholder="Select Department" class="tom-select w-full" name="dept_id" id="dept_id">
                                            <?php if($selectedDept != null): ?>
                                            <option value="<?php echo e($selectedDept->id); ?>" selected><?php echo e($selectedDept->name); ?></option>
                                            <?php else: ?>
                                            <option >Please Select</option>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-5" id="agent_closer"  <?php if($selectedDept->id  != 2): ?> style="display: none" <?php endif; ?>>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-3">
                                    <label for="regular-form-3" class="form-label">User is Agent</label>
                                    <div class="form-check mr-2">
                                        <input class="form-check-input" type="hidden" value="0" name="is_agent">
                                        <input id="checkbox-switch-16" class="form-check-input" type="checkbox" value="1" name="is_agent" <?php if($user->is_agent == 1): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="checkbox-switch-16">Agent</label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-3">
                                    <label for="regular-form-3" class="form-label">User is Closer</label>
                                    <div class="form-check mr-2">
                                        <input class="form-check-input" type="hidden" value="0" name="is_closer">
                                        <input id="checkbox-switch-17" class="form-check-input" type="checkbox" value="1" name="is_closer" <?php if($user->is_closer == 1): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="checkbox-switch-17">Closer</label>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Father Name</label>
                                    <input id="regular-form-3" name="fatherName" value="<?php echo e($user->fatherName); ?>" type="text" class="form-control"
                                        placeholder="Father Name">
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">CNIC Number</label>
                                    <input id="regular-form-3" name="cnic" value="<?php echo e($user->cnic); ?>" type="text" class="form-control"
                                        placeholder="CNIC Number">
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Phone</label>
                                    <input id="regular-form-3" name="phone" value="<?php echo e($user->phone); ?>" type="text" class="form-control"
                                        placeholder="Phone Number">
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Officle Email</label>
                                    <input id="regular-form-3" name="offEmail" value="<?php echo e($user->offEmail); ?>" type="text" class="form-control"
                                        placeholder="Officle Email">
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Personal Email</label>
                                    <input id="regular-form-3" name="perEmail" value="<?php echo e($user->perEmail); ?>" type="text" class="form-control"
                                        placeholder="Personal Email">
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Current Address</label>
                                    <input id="regular-form-3" name="currAddress" value="<?php echo e($user->currAddress); ?>" type="text" class="form-control"
                                        placeholder="Current Address">
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Permenent Address</label>
                                    <input id="regular-form-3" name="perAddress" value="<?php echo e($user->perAddress); ?>" type="text" class="form-control"
                                        placeholder="Permenent Address">
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Vehicle</label>
                                    <select data-placeholder="Select Vehicle" class="tom-select w-full" name="vehicle_id">
                                        <?php if($selectedVehicle != null): ?>
                                        <option value="<?php echo e($selectedVehicle->id); ?>" selected><?php echo e($selectedVehicle->vehicle_number); ?></option>
                                        <?php else: ?>
                                        <option >Please Select</option>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $vehicle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->vehicle_number); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Joining Date</label>
                                    <div class="relative w-100 ">
                                        <div class="absolute rounded-l w-10 h-full flex items-center justify-center bg-slate-100 border text-slate-500 dark:bg-darkmode-700 dark:border-darkmode-800 dark:text-slate-400">
                                            <i data-lucide="calendar" class="w-4 h-4"></i>
                                        </div>
                                        <input type="text" name="joindate" value="<?php echo e($user->joindate); ?>" class="datepicker form-control pl-12" data-single-mode="true">
                                    </div>
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Date of Birth</label>
                                    <div class="relative w-100 ">
                                        <div class="absolute rounded-l w-10 h-full flex items-center justify-center bg-slate-100 border text-slate-500 dark:bg-darkmode-700 dark:border-darkmode-800 dark:text-slate-400">
                                            <i data-lucide="calendar" class="w-4 h-4"></i>
                                        </div>
                                        <input type="text" name="dob" value="<?php echo e($user->dob); ?>" class="datepicker form-control pl-12" data-single-mode="true">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Last Degree</label>
                                    <input id="regular-form-3" name="lastDegree" value="<?php echo e($user->lastDegree); ?>" type="text" class="form-control"
                                        placeholder="Last Degree">
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Running Degree</label>
                                    <input id="regular-form-3" name="currDegree" value="<?php echo e($user->currDegree); ?>" type="text" class="form-control"
                                        placeholder="Running Degree">
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Emergency Contact Name</label>
                                    <input id="regular-form-3" name="emgContactName" value="<?php echo e($user->emgContactName); ?>" type="text" class="form-control"
                                        placeholder="Emergency Contact Name">
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Emergency Contact Number</label>
                                    <input id="regular-form-3" name="emgContactNumber" value="<?php echo e($user->emgContactNumber); ?>" type="text" class="form-control"
                                        placeholder="Emergency Contact Number">
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Emergency Contact Relation</label>
                                    <input id="regular-form-3" name="emgContactRelation" value="<?php echo e($user->emgContactRelation); ?>" type="text" class="form-control"
                                        placeholder="Emergency Contact Relation">
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Gender</label>
                                    <select data-placeholder="Select Gender" class="tom-select w-full" name="gender">
                                        <option >Please Select</option>
                                        <option value="Male" <?php if($user->gender == "Male"): ?> selected <?php endif; ?>>Male</option>
                                        <option value="Female"  <?php if($user->gender == "Female"): ?> selected <?php endif; ?>>Female</option>
                                        <option value="Others"  <?php if($user->gender == "Others"): ?> selected <?php endif; ?>>Others</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Marital Status</label>
                                    <select data-placeholder="Select Marital Status" class="tom-select w-full" name="marital_status">
                                        <option >Please Select</option>
                                        <option value="0" <?php if($user->marital_status == 0): ?> selected <?php endif; ?>>Unmarried</option>
                                        <option value="1" <?php if($user->marital_status == 1): ?> selected <?php endif; ?>>Married</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Employment Type</label>
                                    <select data-placeholder="Select Employment Type" class="tom-select w-full" name="employment_type">
                                        <option >Please Select</option>
                                        <option value="0" <?php if($user->employment_type == 0): ?> selected <?php endif; ?>>Part Time</option>
                                        <option value="1" <?php if($user->employment_type == 1): ?> selected <?php endif; ?>>Full Time</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Blood Group</label>
                                    <input id="regular-form-3" name="blood_group" value="<?php echo e($user->blood_group); ?>" type="text" class="form-control" placeholder="Blood Group">
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Document(s) Description</label>
                                    <input id="regular-form-3" name="doc_desc" value="<?php echo e($user->documents_desc); ?>" type="text" class="form-control"
                                        placeholder="Description" >
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Basic Salary</label>
                                    <input id="regular-form-3" name="basic_salary" type="text" value="<?php echo e($user->basic_salary); ?>"  class="form-control" placeholder="Basic Salary" required>
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Security</label>
                                    <input id="regular-form-3" name="security" type="text" value="<?php echo e($user->Security); ?>"  class="form-control"
                                        placeholder="Security" required>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-3">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Paid Holidays Cycle (Year)</label>
                                    <input id="ph_from"  name="ph_cycle" type="text" class="form-control" value="<?php echo e($user->ph_cycle); ?>"  placeholder="2024">
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-2">
                                    <label for="regular-form-3" class="form-label">Total Paid Holidays</label>
                                    <input id="ph_cycle" name="total_holiday" type="text" class="form-control" value="<?php echo e($user->total_holiday); ?>"   placeholder="12" required>
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-12 gap-6 mt-5">
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-3">
                                    <label for="regular-form-3" class="form-label">Email</label>
                                    <input id="regular-form-3" name="email" value="<?php echo e($user->email); ?>" type="email"  class="form-control"
                                        placeholder="Email" value="<?php echo e($user->email); ?>">
                                </div>
                            </div>
                            <div class="col-span-12 lg:col-span-6">
                                <div class="mt-3">
                                    <label for="regular-form-3" class="form-label">Password</label>
                                    <input id="regular-form-3" name="password" type="Password" class="form-control"
                                        placeholder="Password">
                                </div>
                            </div>

                        </div>
                        <button type="submit" class="btn btn-primary mt-5">Submit</button>
                    </form>
                </div>
            </div>
            <!-- END: Input -->
        </div>
        <!-- END: Content -->
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function(){
        $('#dept_id').change(function(){
            dept = $(this).val();
            // console.log(dept);
            if(dept == 2){
                $('#agent_closer').removeAttr("style");
            }
            else{
                $('#agent_closer').attr("style","display:none;");
            }


            // alert('work');
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\CompleteCRM\resources\views/user/edit.blade.php ENDPATH**/ ?>