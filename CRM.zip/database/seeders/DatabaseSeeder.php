<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\perm;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // perm::insert([
        //     'id' => 3,
        //     'name' => 'Sales',
        //     'role_id' => 1,
        // ]);
    }
}
