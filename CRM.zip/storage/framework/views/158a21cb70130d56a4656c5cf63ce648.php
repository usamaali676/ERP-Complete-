<div
    id="<?php echo e($record->getKey()); ?>"
    wire:click="recordClicked('<?php echo e($record->getKey()); ?>', <?php echo e(@json_encode($record)); ?>)"
    class="record bg-white dark:bg-gray-700 rounded-lg px-4 py-2 cursor-grab font-medium text-gray-600 dark:text-gray-200"
    <?php if($record->timestamps && now()->diffInSeconds($record->{$record::UPDATED_AT}) < 3): ?>
        x-data
        x-init="
            $el.classList.add('animate-pulse-twice', 'bg-primary-100', 'dark:bg-primary-800')
            $el.classList.remove('bg-white', 'dark:bg-gray-700')
            setTimeout(() => {
                $el.classList.remove('bg-primary-100', 'dark:bg-primary-800')
                $el.classList.add('bg-white', 'dark:bg-gray-700')
            }, 3000)
        "
    <?php endif; ?>
>
    <h2> <?php echo e($record->{static::$recordTitleAttribute}); ?></h2>
    <p>Discription: <?php echo e($record->description); ?></p>
    <p>Client: <?php echo e($record->client->sale->business_name); ?></p>
    <p>Dead Line: <?php echo e($record->due_date); ?></p>
    <!--[if BLOCK]><![endif]--><?php if(Auth::user()->role_id == 1): ?>
    <div class="flex -space-x-2">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $record['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-10 h-10 rounded-full  border-2 " style="background-color: #0c5bcb">
            <p class="text-center capitalize flex justify-center items-center h-full flex-wrap text-white " ><?php echo e(substr($user->name, 0, 2)); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


</div>

<?php /**PATH D:\laragon\www\CompleteCRM\resources\views/vendor/filament-kanban/kanban-record.blade.php ENDPATH**/ ?>