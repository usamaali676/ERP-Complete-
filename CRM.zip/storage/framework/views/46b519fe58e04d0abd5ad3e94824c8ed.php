<?php $__env->startSection('content'); ?>
<?php if(Auth::check()): ?>
<?php
// $mperm = App\Models\perm;
$user = Auth::user();
// $perm = App\Models\perm::where('role_id', $user->role_id)->where('name', "Roles")->first();
// $permuser = App\Models\perm::where('role_id', $users->role_id)->where('name', "Users")->first();
$permsheet = App\Models\perm::where('role_id', $user->role_id)->where('name', "Sales")->first();
$permcmnt = App\Models\perm::where('role_id', $user->role_id)->where('name', "cmnt")->first();
?>
<?php endif; ?>
    <div class="content content--top-nav">
        <div class="intro-y flex items-center mt-8">
            <h2 class="text-lg font-medium mr-auto">
                Sales
            </h2>
            <?php if(auth()->user()->is_closer == 1): ?>
            <div class="export-btn px-2">
                <a class="btn btn-primary" href="<?php echo e(route('closed-sales')); ?>" role="button">
                    <i class="fas fa-upload"></i> Sales Closed
                </a>
            </div>
            <?php endif; ?>
            <div class="export-btn px-4">
                <a class="btn btn-outline-primary" href="<?php echo e(route('export')); ?>" role="button">
                    <i class="fas fa-upload"></i> Export
                </a>
            </div>

             <?php if($permsheet->create == 1): ?>
            <div class="import-btn">
                <a class="btn btn-outline-primary" href="<?php echo e(route('sales.create')); ?>" role="button">
                    <i class="fas fa-upload"></i> Add Manually
                </a>
            </div>
            <div id="button-modal" class="p-5">
                <div class="preview">

                    <!-- BEGIN: Modal Toggle -->
                    <div class="text-center"> <a href="javascript:;" data-tw-toggle="modal"
                            data-tw-target="#button-modal-preview" class="btn btn-primary">Import Data</a> </div>
                    <!-- END: Modal Toggle -->
                    <!-- BEGIN: Modal Content -->
                    <div id="button-modal-preview" class="modal" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <a data-tw-dismiss="modal" href="javascript:;"> <i data-lucide="x"
                                        class="w-8 h-8 text-slate-400"></i> </a>
                                <div class="modal-body p-5">
                                    <div class="p-5 text-center">
                                        <form action="<?php echo e(route('file-import')); ?>" method="POST"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group ">
                                                <div class="fallback">
                                                    <input name="file" type="file" name="file" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" required/>
                                                </div>
                                                

                                            </div>

                                            

                                    </div>
                                    <div class="px-5 pb-8 text-center">
                                        <button class="btn btn-primary">Submit</button>

                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END: Modal Content -->
                </div>
            </div>
            <?php endif; ?>
        </div>
        <!-- BEGIN: Striped Rows -->
        <div class="intro-y box mt-5">
            <div class="p-5" >
                    <div class="overflow-x-auto">

                        <table id="example" class="table table-report">
                                            <thead>
                                                <tr>
                                                    <th class="whitespace-nowrap">Sr.</th>
                                                    <th class="whitespace-nowrap">Business Name</th>
                                                    <th class="whitespace-nowrap">Business Number</th>
                                                    <th class="whitespace-nowrap">Email</th>
                                                    <th class="whitespace-nowrap">Agent</th>
                                                    <th class="whitespace-nowrap">Closer</th>

                                                    

                                                    <th class="whitespace-nowrap">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(Auth::check()): ?>
                                                <?php if(auth()->user()->id == $item->agent_id  || auth()->user()->role_id == 1): ?>
                                                <tr >
                                                    <td><?php echo e($srno++); ?></td>
                                                    <td><?php echo e($item->business_name); ?></td>
                                                    <td><?php echo e($item->business_number); ?></td>
                                                    <td><?php echo e($item->email); ?></td>
                                                    <td><?php echo e($item->agent->name); ?></td>
                                                    <td><?php echo e($item->closer->name); ?></td>
                                                    

                                                     <td><?php if($permsheet->edit == 1): ?><a class="btn btn-warning mr-1 mb-2" href="<?php echo e(route('sales.edit',$item->id)); ?>" > <i data-lucide="edit" style="color: #fff" class="w-5 h-5"></i> </a><?php endif; ?> <?php if($permsheet->view == 1): ?><a href="<?php echo e(route('sale-datail', $item->id)); ?>" class="btn btn-success mr-1 mb-2"> <i data-lucide="eye" class="w-5 h-5" style="color: #fff"></i> </a><?php endif; ?> <?php if($permsheet->delete == 1): ?><a href="<?php echo e(route('sales.conf-delete', $item->id)); ?>" class="btn btn-danger mr-1 mb-2"> <i data-lucide="trash" class="w-5 h-5"></i> </a><?php endif; ?> <?php if($permcmnt->create == 1): ?><a href="<?php echo e(route('cmnt.create', $item->id)); ?>" class="btn btn-primary mr-1 mb-2"> <i data-lucide="message-circle" class="w-5 h-5"></i> </a><?php endif; ?> <?php if($permsheet->edit == 1): ?><a href="<?php echo e(route('clients.create', $item->id)); ?>" class="btn btn-success mr-1 mb-2"> <i data-lucide="user-check" class="w-5 h-5" style="color: #fff"></i> </a><?php endif; ?></td>
                                                </tr>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>
                    </table>
                </div>

            </div>
        </div>
        <!-- END: Striped Rows -->
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CRM\resources\views/sheet.blade.php ENDPATH**/ ?>